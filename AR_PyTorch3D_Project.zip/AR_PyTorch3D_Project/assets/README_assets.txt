Place your printed checkerboard or ArUco marker in this folder.
Recommended checkerboard: 8x6 inner corners, square size = 24 mm (0.024 m).